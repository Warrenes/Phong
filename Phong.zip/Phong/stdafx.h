#pragma once
#include "pch.h"
#include "Reflectivity.h"
extern Reflectivity reflectivity;

