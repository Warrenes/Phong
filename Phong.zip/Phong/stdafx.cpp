#include "pch.h"
#include "Reflectivity.h"
Reflectivity reflectivity;